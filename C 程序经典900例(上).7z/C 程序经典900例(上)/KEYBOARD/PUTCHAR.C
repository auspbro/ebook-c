#include <stdio.h>

void main(void)
 {
   int letter;

   for (letter = 'A'; letter <= 'Z'; letter++)
     putchar(letter);
 }

