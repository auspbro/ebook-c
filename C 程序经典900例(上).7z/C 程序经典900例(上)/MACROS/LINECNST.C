#include <stdio.h>

void main ()
 {
   printf("Successfully reached line %d\n", __LINE__);

   // Other statements here
   
   printf("Successfully reached line %d\n", __LINE__);
 }
