#include <stdio.h>

int tip_count = 1001;  // Global variable

void show_title(void)
 {
   printf("Jamsa's 1001 C/C++ Tips");
 }

