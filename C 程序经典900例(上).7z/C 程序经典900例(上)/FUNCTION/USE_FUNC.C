#include <stdio.h>

void hello_world(void)
 { 
   printf("Hello, world!\n");
 }

void main(void)
 {
   hello_world();
 }
