#include <stdio.h>

void main(void)
 {
   extern int tip_count;

   printf("The number of tips is %d\n", tip_count);
 }

