#include <stdio.h>
#include <math.h>

void main (void)
 {
   printf("10 raised to -1 is %f\n", pow10(-1));
   printf("10 raised to 0 is %f\n", pow10(0));
   printf("10 raised to 1 is %f\n", pow10(1));
   printf("10 raised to 2 is %f\n", pow10(2));
}
