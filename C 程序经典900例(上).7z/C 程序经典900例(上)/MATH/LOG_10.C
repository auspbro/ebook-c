#include <stdio.h>
#include <math.h>

void main (void)
 {
   printf("Log10 of 100 is %f\n", log10(100.0));
   printf("Log10 of 10000 is %f\n", log10(10000.0));
 }
