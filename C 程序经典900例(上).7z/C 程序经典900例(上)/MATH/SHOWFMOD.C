#include <stdio.h>
#include <math.h>

void main (void)
 {
   double numerator = 10.0;
   double denominator = 3.0;

   printf("fmod(10, 3) is %f\n", fmod(numerator,
    denominator));
 }

